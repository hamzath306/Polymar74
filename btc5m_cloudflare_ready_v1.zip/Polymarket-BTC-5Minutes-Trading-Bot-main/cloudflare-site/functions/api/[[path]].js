export async function onRequest(context) {
  const { request, env } = context;
  if (!env.BOT_API_URL || !env.BOT_API_TOKEN) return Response.json({error:"backend_not_configured"}, {status:503});
  const incoming = new URL(request.url);
  const path = incoming.pathname.replace(/^\/api/, "");
  const target = new URL("/api" + path, env.BOT_API_URL);
  const headers = new Headers(request.headers);
  headers.set("Authorization", `Bearer ${env.BOT_API_TOKEN}`);
  headers.delete("host");
  const upstream = await fetch(target, {method: request.method, headers, body: ["GET","HEAD"].includes(request.method) ? undefined : request.body, redirect:"manual"});
  return new Response(upstream.body, {status:upstream.status, headers:{"Content-Type":upstream.headers.get("Content-Type") || "application/json", "Cache-Control":"no-store"}});
}
