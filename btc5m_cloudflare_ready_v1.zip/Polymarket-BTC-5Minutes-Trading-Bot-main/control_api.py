from __future__ import annotations
import hmac, json, os, signal, subprocess, sys, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
STATUS = ROOT / ".cloud_control_status.json"
PROFILES = {
    "scalper": {"PREDICTOR_POLL_SECONDS": "1.35", "PREDICTOR_MIN_SCORE": "0.52", "PREDICTOR_REQUIRE_TREND_ALIGN": "1", "PREDICTOR_REQUIRE_CANDLE_ALIGN": "0", "MAX_DAILY_TRADES": "0", "DAILY_WIN_TARGET": "50"},
    "medium": {"PREDICTOR_POLL_SECONDS": "1.0", "PREDICTOR_MIN_SCORE": "0.50", "PREDICTOR_REQUIRE_TREND_ALIGN": "1", "PREDICTOR_REQUIRE_CANDLE_ALIGN": "0", "MAX_DAILY_TRADES": "0", "DAILY_WIN_TARGET": "50"},
    "elite": {"PREDICTOR_POLL_SECONDS": "2.0", "PREDICTOR_MIN_SCORE": "0.70", "PREDICTOR_REQUIRE_TREND_ALIGN": "1", "PREDICTOR_REQUIRE_CANDLE_ALIGN": "1", "MAX_DAILY_TRADES": "3", "DAILY_WIN_TARGET": "50"},
}
TOKEN = os.environ.get("BOT_CONTROL_TOKEN", "")


def read_status():
    try:
        data = json.loads(STATUS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"running": False, "profile": None, "mode": "stopped"}
    pid = int(data.get("pid", 0))
    alive = False
    if pid > 0:
        try:
            os.kill(pid, 0); alive = True
        except OSError:
            pass
    if not alive:
        return {"running": False, "profile": data.get("profile"), "mode": "stopped", "last_exit_at": data.get("started_at")}
    return {"running": True, "pid": pid, "profile": data.get("profile"), "mode": data.get("mode", "practice"), "started_at": data.get("started_at")}


def stop_bot():
    try:
        data = json.loads(STATUS.read_text(encoding="utf-8"))
        pid = int(data.get("pid", 0))
    except (OSError, ValueError):
        return
    if pid <= 0: return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, check=False)
        else:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
    except (OSError, ProcessLookupError):
        pass
    try: STATUS.unlink()
    except OSError: pass


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[control-api] " + (fmt % args))

    def send_json(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(body)

    def authorized(self):
        supplied = self.headers.get("Authorization", "")
        return bool(TOKEN) and hmac.compare_digest(supplied, "Bearer " + TOKEN)

    def do_GET(self):
        if urlparse(self.path).path != "/api/status": return self.send_json(404, {"error":"not_found"})
        if not self.authorized(): return self.send_json(401, {"error":"unauthorized"})
        return self.send_json(200, read_status())

    def do_POST(self):
        if not self.authorized(): return self.send_json(401, {"error":"unauthorized"})
        route = urlparse(self.path).path
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 4096)
            body = json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            return self.send_json(400, {"error":"invalid_json"})
        if route == "/api/stop":
            stop_bot(); return self.send_json(200, {"ok": True, "status": read_status()})
        if route != "/api/start": return self.send_json(404, {"error":"not_found"})
        if read_status().get("running"): return self.send_json(409, {"error":"already_running"})
        profile = str(body.get("profile", "scalper")).lower()
        if profile not in PROFILES: return self.send_json(400, {"error":"invalid_profile"})
        mode = str(body.get("mode", "practice")).lower()
        if mode not in {"practice", "live"}: return self.send_json(400, {"error":"invalid_mode"})
        if mode == "live" and not (os.getenv("ALLOW_LIVE_TRADING") == "1" and body.get("confirm_live") is True):
            return self.send_json(403, {"error":"live_disabled_or_unconfirmed"})
        env = os.environ.copy(); env.update(PROFILES[profile]); env["TRADING_PROFILE"] = profile
        # Fixed stake, no loss-recovery/martingale sizing.
        env["FIXED_STAKE_USD"] = env.get("MARKET_BUY_USD", "1")
        args = [sys.executable, str(ROOT / "5m_bot_runner.py")]
        if mode == "live": args.append("--live")
        else: args.append("--test-mode")
        (ROOT / "logs").mkdir(exist_ok=True)
        log_handle = open(ROOT / "logs" / "control_runner.log", "a", encoding="utf-8")
        kwargs = {"cwd": str(ROOT), "env": env, "stdin": subprocess.DEVNULL, "stdout": log_handle, "stderr": subprocess.STDOUT}
        if os.name != "nt": kwargs["start_new_session"] = True
        proc = subprocess.Popen(args, **kwargs)
        data = {"pid": proc.pid, "profile": profile, "mode": mode, "started_at": datetime.now(timezone.utc).isoformat()}
        STATUS.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return self.send_json(200, {"ok": True, "status": read_status()})


def main():
    if not TOKEN:
        raise SystemExit("Set BOT_CONTROL_TOKEN before starting the control API.")
    host = os.environ.get("BOT_CONTROL_HOST", "127.0.0.1")
    port = int(os.environ.get("BOT_CONTROL_PORT", "8788"))
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"Control API listening on {host}:{port}; protect it behind Cloudflare Tunnel/VPN.")
    server.serve_forever()

if __name__ == "__main__": main()
