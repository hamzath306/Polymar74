# BTC Poly AI — Cloudflare-ready package

This package contains the original Polymarket BTC 5-minute bot, a private control API, and a Cloudflare Pages dashboard with three selectable profiles. **The `.env` file from the source archive is intentionally excluded**; create your own `.env` from `.env.example` on the private bot host.

## Profiles
- `scalper`: predictor poll 1.35s, score floor 0.52, trend confirmation, daily stop after 50 resolved wins.
- `medium`: predictor poll 1.0s (35% faster polling rate than 1.35s), score floor 0.50, trend confirmation, daily stop after 50 resolved wins.
- `elite`: score floor 0.70, trend + candle confirmation, maximum 3 submitted trades per UTC day.

All profiles use a fixed stake; loss-recovery/martingale sizing is disabled in the predictor path. These profiles configure the current 5-minute contract bot. Polling faster does **not** turn 5-minute Polymarket contracts into 30-second contracts or implement early exits. A true 30-second entry/exit scalper requires a separate verified sell/position-management engine before live trading.

## 1. Run the bot and private API on a persistent server
1. Upload/extract this project to a private Linux VPS/VM (not Pages).
2. Create `.env` from `.env.example` and enter your Polymarket credentials **only on that server**. Never upload `.env` to GitHub, Pages, or this ZIP.
3. Install dependencies as described in the original README (`pip install -r requirements.txt`).
4. Set a strong random `BOT_CONTROL_TOKEN` in the server environment. Keep `BOT_CONTROL_HOST=127.0.0.1` and `BOT_CONTROL_PORT=8788`.
5. Start the API: `python control_api.py`. Keep it private; expose it only via Cloudflare Tunnel/Access or another authenticated private path. Do not expose port 8788 directly to the public internet.
6. Live trading is disabled unless `ALLOW_LIVE_TRADING=1` is set on the private server; practice is the default. The Cloudflare dashboard currently exposes practice start/stop only.

## 2. Deploy the website to Cloudflare Pages
1. Create a Pages project and upload the contents of `cloudflare-site/`, or connect a private Git repository containing the project. Build output directory: `public`; no build command is needed.
2. In Pages → Settings → Environment variables, set `BOT_API_URL` to the private HTTPS origin for the control API and `BOT_API_TOKEN` to the same strong token configured on the bot server. Prefer Cloudflare Tunnel + Access. Never add this token to browser JavaScript.
3. Redeploy after setting the variables. The status panel should report backend connectivity; start in practice mode only.

## Safety / current limitations
- No claim of guaranteed wins or guaranteed daily profit. The 50 figure is a stop target for *resolved wins*, not a promise that the market will produce 50 winners.
- Elite 3 means at most three submitted trades per UTC day, not three guaranteed wins.
- This codebase trades 5-minute Polymarket markets and ordinarily holds contracts until resolution; it does not yet support true 30-second chart-driven early exits. Keep live trading off until that engine is implemented and tested.
- The dashboard shows backend status, not fake live prices/P&L.
- The API is authenticated but should still sit behind Cloudflare Tunnel/Access or VPN.
